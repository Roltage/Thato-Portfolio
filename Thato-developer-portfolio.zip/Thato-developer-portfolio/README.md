# Thato Mofokeng — Developer Portfolio

A responsive React portfolio for showcasing software development, databases, AI projects and web work. Built with Vite and designed for deployment to GitHub Pages.

## Run locally

1. Install [Node.js LTS](https://nodejs.org/).
2. Open this folder in VS Code.
3. Open the terminal and run:

   ```bash
   npm install
   npm run dev
   ```

4. Open the local URL Vite prints in the terminal.

## Personalise before publishing

Open `src/main.jsx` and update the `profile` object:

- `email`: your professional email address
- `github`: your GitHub profile URL
- `linkedin`: confirm your LinkedIn URL
- `cv`: optional path to your CV PDF

Then update each project link in the `projects` array to the correct repository. Remove or edit projects that are not yet public, and make sure descriptions accurately represent what you have built.

To add a CV, create a `public` folder, put your PDF inside it, and set `cv: '/Your-CV-Filename.pdf'`.

## Publish with GitHub Pages

This repository includes a GitHub Actions workflow at `.github/workflows/deploy.yml`.

1. Create a new GitHub repository, for example `thato-portfolio`.
2. Upload/push all files and folders from this project to the repository's `main` branch. Keep `.github/workflows/deploy.yml`.
3. On GitHub, open the repository and go to **Settings → Pages**.
4. Under **Build and deployment**, set **Source** to **GitHub Actions**.
5. Open the **Actions** tab and wait for **Deploy portfolio to GitHub Pages** to finish successfully.
6. Your site URL will usually be `https://YOUR-GITHUB-USERNAME.github.io/thato-portfolio/`. Find the exact URL under **Settings → Pages**.

The included Vite configuration uses relative asset paths, so the site can be deployed from a project repository or a user-site repository.

## Tech stack

- React
- Vite
- Lucide icons
- Responsive CSS
- GitHub Actions + GitHub Pages

## Notes

- Replace all `YOUR-GITHUB-USERNAME` placeholders before publishing.
- Do not put API keys, `.env` files or other secrets in this portfolio repository.
- Google Fonts are loaded from an external service; fallback fonts are used if they cannot load.

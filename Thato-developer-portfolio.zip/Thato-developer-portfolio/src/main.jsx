import React from "react";
import { createRoot } from "react-dom/client";
import {
  ArrowDownRight,
  ArrowUpRight,
  Github,
  Linkedin,
  Mail,
  Code2,
  Database,
  BrainCircuit,
  Globe2,
  Terminal,
  ExternalLink,
  Menu,
  X,
  Sparkles,
} from "lucide-react";
import "./styles.css";

const profile = {
  name: "Thato Mofokeng",
  email: "thatomofokeng89@gmail.com",
  github: "https://github.com/Roltage",
  linkedin: "https://www.linkedin.com/in/thato-mofokeng-65611b19a/",
  cv: "/Thato-Mofokeng-CV.pdf",
};

const projects = [
  {
    number: "01",
    title: "The Lynx Project",
    type: "Python · AI · Voice",
    description:
      "A personal AI assistant inspired by JARVIS, combining voice recognition, spoken responses and AI-powered conversation.",
    tags: ["Python", "OpenAI API", "SpeechRecognition", "pyttsx3"],
    icon: BrainCircuit,
    link: "https://github.com/YOUR-GITHUB-USERNAME/PROJECT-JARVIS-LYNX",
    status: "In progress",
  },
  {
    number: "02",
    title: "Employee Management System",
    type: "Java · Database",
    description:
      "A Java application project focused on employee records and the core workflows of an employee management system.",
    tags: ["Java", "SQL", "JDBC", "CRUD"],
    icon: Database,
    link: "https://github.com/YOUR-GITHUB-USERNAME",
    status: "Academic project",
  },
  {
    number: "03",
    title: "Database Development",
    type: "SQL · Data modelling",
    description:
      "A collection of database exercises and coursework demonstrating SQL querying, relational database concepts and data management.",
    tags: ["SQL Server", "T-SQL", "Database design"],
    icon: Terminal,
    link: "https://github.com/YOUR-GITHUB-USERNAME",
    status: "Portfolio collection",
  },
  {
    number: "04",
    title: "Postnet Website Redesign",
    type: "Web · UI/UX",
    description:
      "A website redesign project exploring low-fidelity wireframes, high-fidelity screens and a clearer user experience.",
    tags: ["Figma", "UI/UX", "Prototyping"],
    icon: Globe2,
    link: "https://github.com/YOUR-GITHUB-USERNAME",
    status: "Academic project",
  },
];
const skills = [
  {
    title: "Software development",
    text: "Java, Python, C# fundamentals, object-oriented programming and debugging",
    icon: Code2,
  },
  {
    title: "Databases",
    text: "SQL, SQL Server, T-SQL, relational design and database development",
    icon: Database,
  },
  {
    title: "AI & automation",
    text: "OpenAI API integration, speech recognition and Python automation",
    icon: BrainCircuit,
  },
  {
    title: "Web development",
    text: "HTML, CSS, JavaScript, responsive UI and Git/GitHub workflows",
    icon: Globe2,
  },
];

function App() {
  const [menuOpen, setMenuOpen] = React.useState(false);
  const closeMenu = () => setMenuOpen(false);
  return (
    <div className="site-shell">
      <header className="topbar">
        <a
          className="brand"
          href="#home"
          onClick={closeMenu}
          aria-label="Thato Mofokeng home"
        >
          <span className="brand-mark">TM</span>
          <span>
            THATO MOFOKENG<span className="brand-sub">DEVELOPER PORTFOLIO</span>
          </span>
        </a>
        <button
          className="menu-toggle"
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Toggle navigation"
        >
          {menuOpen ? <X size={21} /> : <Menu size={21} />}
        </button>
        <nav className={menuOpen ? "nav nav-open" : "nav"}>
          <a href="#about" onClick={closeMenu}>
            About
          </a>
          <a href="#skills" onClick={closeMenu}>
            Skills
          </a>
          <a href="#projects" onClick={closeMenu}>
            Projects
          </a>
          <a href="#contact" onClick={closeMenu}>
            Contact
          </a>
          <a
            className="nav-cta"
            href={profile.github}
            target="_blank"
            rel="noreferrer"
          >
            GitHub <ArrowUpRight size={15} />
          </a>
        </nav>
      </header>
      <main>
        <section className="hero section-wrap" id="home">
          <div className="hero-copy">
            <div className="eyebrow">
              <span className="status-dot" /> OPEN TO JUNIOR OPPORTUNITIES
            </div>
            <h1>
              Building useful
              <br />
              <span>digital solutions.</span>
            </h1>
            <p className="hero-intro">
              I'm {profile.name}, an aspiring software developer interested in
              building practical applications across software, databases, AI and
              the web.
            </p>
            <div className="hero-actions">
              <a className="button button-primary" href="#projects">
                Explore my work <ArrowDownRight size={17} />
              </a>
              <a className="button button-quiet" href="#contact">
                Let's connect <ArrowUpRight size={17} />
              </a>
            </div>
            <div className="hero-meta">
              <span>
                <Code2 size={16} /> Software development
              </span>
              <span>
                <Database size={16} /> Database development
              </span>
            </div>
          </div>
          <div
            className="hero-art"
            aria-label="Abstract developer illustration"
          >
            <div className="art-grid" />
            <div className="orbit orbit-one" />
            <div className="orbit orbit-two" />
            <div className="code-card">
              <div className="code-card-top">
                <span />
                <span />
                <span />
                <small>developer.js</small>
              </div>
              <div className="code-lines">
                <p>
                  <i>01</i> <b>const</b> developer = {"{"}
                </p>
                <p>
                  <i>02</i> &nbsp; name: <em>'Thato'</em>,
                </p>
                <p>
                  <i>03</i> &nbsp; focus: [
                </p>
                <p>
                  <i>04</i> &nbsp;&nbsp; <em>'software'</em>,
                </p>
                <p>
                  <i>05</i> &nbsp;&nbsp; <em>'databases'</em>,
                </p>
                <p>
                  <i>06</i> &nbsp;&nbsp; <em>'AI + web'</em>
                </p>
                <p>
                  <i>07</i> &nbsp; ],
                </p>
                <p>
                  <i>08</i> &nbsp; learning: <strong>true</strong>
                </p>
                <p>
                  <i>09</i> {"}"}
                </p>
              </div>
              <div className="code-card-foot">
                <span className="pulse" /> Always building, always learning
              </div>
            </div>
            <div className="floating-chip chip-top">
              <Sparkles size={15} /> Curiosity → code
            </div>
            <div className="floating-chip chip-bottom">
              <Database size={15} /> Data-driven thinking
            </div>
          </div>
          <a className="scroll-cue" href="#about">
            <span /> SCROLL TO EXPLORE
          </a>
        </section>
        <section className="about section-wrap section-block" id="about">
          <div className="section-heading">
            <span className="section-kicker">01 / ABOUT</span>
            <h2>
              Curious by nature.
              <br />
              <span>Developer by choice.</span>
            </h2>
          </div>
          <div className="about-content">
            <p className="large-copy">
              I enjoy understanding how things work and turning ideas into
              software that solves real problems.
            </p>
            <p>
              I'm completing an IT diploma focused on software development and
              database development. Through academic work and personal projects,
              I'm building practical experience with programming, data, APIs and
              user-focused design.
            </p>
            <p>
              I'm keen to keep learning, collaborate with others and contribute
              to a team where I can grow as a developer.
            </p>
            <div className="about-links">
              <a href={profile.github} target="_blank" rel="noreferrer">
                <Github size={17} /> GitHub <ArrowUpRight size={14} />
              </a>
              <a href={profile.linkedin} target="_blank" rel="noreferrer">
                <Linkedin size={17} /> LinkedIn <ArrowUpRight size={14} />
              </a>
            </div>
          </div>
        </section>
        <section className="skills-section section-block" id="skills">
          <div className="section-wrap">
            <div className="section-heading heading-row">
              <div>
                <span className="section-kicker">02 / CAPABILITIES</span>
                <h2>
                  Tools for turning
                  <br />
                  <span>ideas into reality.</span>
                </h2>
              </div>
              <p className="heading-note">
                A growing toolkit across code, data and digital experiences.
              </p>
            </div>
            <div className="skills-grid">
              {skills.map((skill, index) => {
                const Icon = skill.icon;
                return (
                  <article className="skill-card" key={skill.title}>
                    <div className="skill-card-top">
                      <span>0{index + 1}</span>
                      <Icon size={22} />
                    </div>
                    <h3>{skill.title}</h3>
                    <p>{skill.text}</p>
                  </article>
                );
              })}
            </div>
            <p className="skills-note">
              Skills listed reflect areas of study and project experience.
              Adjust technologies as your experience grows.
            </p>
          </div>
        </section>
        <section className="projects section-wrap section-block" id="projects">
          <div className="section-heading heading-row">
            <div>
              <span className="section-kicker">03 / SELECTED WORK</span>
              <h2>
                Projects with a<br />
                <span>purpose.</span>
              </h2>
            </div>
            <p className="heading-note">
              A selection of academic and personal work. Each project is an
              opportunity to learn, experiment and improve.
            </p>
          </div>
          <div className="projects-grid">
            {projects.map((project) => {
              const Icon = project.icon;
              return (
                <article className="project-card" key={project.number}>
                  <div className="project-top">
                    <span className="project-number">{project.number}</span>
                    <span className="project-status">{project.status}</span>
                  </div>
                  <div className="project-icon">
                    <Icon size={23} />
                  </div>
                  <span className="project-type">{project.type}</span>
                  <h3>{project.title}</h3>
                  <p>{project.description}</p>
                  <div className="tag-list">
                    {project.tags.map((tag) => (
                      <span key={tag}>{tag}</span>
                    ))}
                  </div>
                  <a
                    className="project-link"
                    href={project.link}
                    target="_blank"
                    rel="noreferrer"
                  >
                    View project <ExternalLink size={15} />
                  </a>
                </article>
              );
            })}
          </div>
          <div className="github-banner">
            <div>
              <Github size={23} />
              <div>
                <strong>More work lives on GitHub.</strong>
                <p>Explore repositories, code and project updates.</p>
              </div>
            </div>
            <a
              className="button button-dark"
              href={profile.github}
              target="_blank"
              rel="noreferrer"
            >
              Visit GitHub <ArrowUpRight size={16} />
            </a>
          </div>
        </section>
        <section className="contact-section section-block" id="contact">
          <div className="section-wrap contact-inner">
            <div>
              <span className="section-kicker">04 / CONTACT</span>
              <h2>
                Have an opportunity
                <br />
                or an idea? <span>Let's talk.</span>
              </h2>
              <p>
                I'm interested in junior opportunities, collaborative projects
                and conversations about technology.
              </p>
            </div>
            <div className="contact-actions">
              <a
                className="button button-primary"
                href={`mailto:${profile.email}`}
              >
                <Mail size={17} /> Email me <ArrowUpRight size={16} />
              </a>
              <a
                className="contact-text-link"
                href={profile.linkedin}
                target="_blank"
                rel="noreferrer"
              >
                <Linkedin size={17} /> Connect on LinkedIn{" "}
                <ArrowUpRight size={15} />
              </a>
              {profile.cv && (
                <a className="contact-text-link" href={profile.cv}download>
                  <span>↓</span> Download my CV <ArrowUpRight size={15} />
                </a>
              )}
              {!profile.cv && (
                <span className="cv-hint">
                  Add your CV PDF to the public folder and set the CV path in
                  src/main.jsx.
                </span>
              )}
            </div>
          </div>
        </section>
      </main>
      <footer className="footer section-wrap">
        <a className="brand footer-brand" href="#home">
          <span className="brand-mark">TM</span>
          <span>
            THATO MOFOKENG<span className="brand-sub">DEVELOPER PORTFOLIO</span>
          </span>
        </a>
        <p>Designed with intent. Built with curiosity.</p>
        <span>© {new Date().getFullYear()} Thato Mofokeng</span>
      </footer>
    </div>
  );
}

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
